# SADO Link — ilk deneme sürümü

Windows 11 / Python **3.10 veya üzeri**. Bu bağımsız bir tuş/fare aktarım prototipidir;
eski SEGE programının içine kurulmaz. Warrior veya Mage kombosu üretmez: senin
elle bastığın tuşları ve fare olaylarını aktarır. Python'un resmi Windows
kurulumunda gelen tkinter arayüzünü kullanır.

## Arkadaşın çevrimdışıyken hemen dene

1. ZIP dosyasını tamamen bir klasöre çıkar. ZIP içinden çalıştırma.
2. `TEST_BASLAT.bat` dosyasına çift tıkla. İlk açılışta internetten Python
   bağımlılıkları indirilir; sonraki açılışlarda mevcut kurulum kullanılır.
3. **GÖNDERİCİ** ve **ALICI** başlıklı iki pencere açılır, otomatik bağlanır.
   Üst üste açılırlarsa yan yana taşı.
4. Önce **ALICI** penceresinde **AKTARIMI ETKİNLEŞTİR** düğmesine bas.
5. Sonra **GÖNDERİCİ** penceresinde **AKTARIMI ETKİNLEŞTİR** düğmesine bas.
6. Göndericinin yeşil çerçeveli **TEST ALANINA** tıkla. W/A/S/D, 1/2/3,
   sağ/sol fare ve tekerleği dene. Fareyi bu alanın içinde hareket ettir.
7. Alıcıda olay sayısının artmasını, fare işaretinin hareket etmesini ve
   BASILDI/BIRAKILDI kayıtlarını gör. Örneğin **W = VK 87**, **1 = VK 49**.
8. W'yi basılı tutup bırak: alıcıdaki basılı tuş listesine eklenip çıkmalı.
9. **F12** veya **DURDUR**: aktarım durmalı, basılı tuşlar listesi boşalmalı.
   Yeniden başlatırken gerekirse önce alıcı onayını, sonra göndericiyi aç.
10. Bir pencereyi kapat: diğerinde eşleşme/onay kapanmalı. İki pencereyi de
    kapatınca yerel sunucu ve başlatma konsolu sonlanır.

Bu modda gerçek klavye veya fare kontrolü uygulanmaz. Gerçek girdi seçeneği
özellikle kilitlidir. Test alanından başka yere tıklamak basılı tuş durumunu
sıfırlar; bilgisayarındaki diğer uygulamalarda yazdıkların aktarılmaz.
Test ekranındaki olay kayıtları diske kaydedilmez.

## Arkadaşın geldiğinde internetten kullanım

Yerel test sunucusu yalnızca **bu bilgisayarda** çalışır. `127.0.0.1` adresini
arkadaşına göndererek bağlanamazsın. İki ev arasında kullanım için ayrıca
ulaşılabilir bir **WSS/TLS aracı sunucu** kurulmalıdır. Bu pakette sunucu kodu
var; hazır barındırılan sunucu veya canlı internet adresi yoktur.

Aracı sunucu hazırlandıktan sonra:

1. İkiniz de `PROGRAM_BASLAT.bat` açın.
2. Aynı `wss://...` sunucu adresini girin.
3. Sen `sender`, arkadaşın `receiver` seçsin. Senin pencerenin ürettiği
   uzun oturum kodunu yalnızca arkadaşınla paylaş; ikiniz aynı kodu kullanın.
4. Önce test modu ile iki ev arasında olayların geldiğini doğrulayın.
5. Bağlantıyı kesin. İkiniz de **GERÇEK GİRDİ** seçeneğini açıp hedef oyun
   pencere başlığından ayırt edici bir parça girin (varsayılan `Knight`).
   Yeniden bağlanıp gösterilen gerçek girdi onayını kabul edin.
6. Önce alıcı aktarımı etkinleştirsin ve oyun penceresine geçsin; sonra sen
   gönderimi etkinleştirip kendi oyun pencerene geç.
7. Tuş basma/bırakma, fare hareketi, sol/sağ/orta tık ve tekerlek aktarılır.

**F12** gerçek girdi modunda iki tarafta da global durdurmadır ve karşıya
aktarılmaz. Alıcı oyun penceresi odağını kaybederse onay kapanır. Gönderici
odağı kaybederse basılı girdiler sıfırlanır; oyun dışındaki yeni girdiler
aktarılmaz. Pencereleri kapatırken veya bağlantı kaybolunca programın bastığı
tuşlar/fare düğmeleri bırakılır. Yanıt vermeyen sunucu uygulama heartbeat'iyle
yaklaşık 4 saniyede fark edilir; ağ/işletim sistemi koşulları süreyi uzatabilir.
Bağlantı geri gelse bile otomatik yeniden aktarım yapılmaz.

Fare konumu, gönderenin oyun penceresinin iç alanındaki orana göre alıcı
penceresine uyarlanır. İkinizde aynı oyun arayüzü, kamera ve beceri düzeni
olması gerekir. Aynı tıklama farklı karakter/hedef konumlarında farklı sonuç
verebilir. İnternet gecikmesi vardır; tam eşzamanlılık garantisi yoktur.

Gerçek girdi, pynput/Windows girdisi kullanır. Interception sürücüsü içermez.
Oyunun bu girdileri kabul etmesi Windows üzerinde ayrıca denenmelidir; kernel
sürücüsü veya oyun korumasını aşmaya yönelik bir uygulama bulunmaz.

## Sunucu yöneticisi için

Python 3.10+ ile bağımlılıkları kur:

```sh
python -m venv .venv
# Windows: .venv\Scripts\python.exe
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python relay.py --host 127.0.0.1 --port 8765
```

TLS sonlandıran bir reverse proxy'yi `wss://alan-adiniz` üzerinden bu yerel
porta yönlendir; WebSocket Upgrade ve uzun bağlantıları desteklesin. TLS
sertifikasının doğrulanmasını kapatma. Kullanıcı makinelerindeki istemciler
uzak sunucu için yalnız `wss://` kabul eder. Yerel `ws://` istisnası loopback
adresleriyle sınırlıdır. Oyun oynayan bilgisayarlarda port açılması gerekmez.

Oturum kodu 192 bit rastgelelik taşır; kodu bilen biri odaya katılabilir.
Her odada en fazla bir gönderici ve bir alıcı bulunur. Sunucu olayları
görebilir; aktarım uçtan uca şifrelenmiş değildir, iki TLS bağlantısı kullanır.
Kodları ve girdi içeriklerini reverse proxy loglarına eklemeyin. Sunucu
genel kullanıma açılacaksa bağlantı oran sınırlaması ve işletim izlemesi de
yapılmalıdır. Bu paket bu barındırma işlemlerini otomatik yapmaz.

## Kontroller ve sınırlar

```sh
.venv/bin/python -m unittest discover -s tests -v
```

Relay testleri: alıcı onayı öncesi olay engelleme, tuş/fare/tekerlek aktarımı,
sıfırlama, kopuşta onay kapatma, tekrar bağlantıda yeni onay, oda ayrımı,
aynı rolün ikinci kez bağlanmasını reddetme, bozuk olayları/F12'yi reddetme
ve uzak bağlantıda TLS zorunluluğunu doğrular.

Bu paket Linux'ta **8 başarılı testle** doğrulanmıştır. Bunlardan biri sanal
ekranda iki gerçek Tk penceresi ve gerçek WebSocket bağlantısı kullanarak
W basma/bırakma, fare hareketi/tıklaması, F12 ve kopuş davranışını denedi.
Ayrı bir test, bağlantı açık kalsa bile sunucu uygulaması yanıt vermediğinde
istemcinin heartbeat süresi sonunda bağlantıyı kapattığını doğruladı.
Windows 11'de gerçek girdi ve oyun uyumluluğu henüz doğrulanmamıştır. İlk
kullanıcı denemesi için yukarıdaki yerel TEST modunu kullan.

## Sorun giderme

- Python bulunamazsa Python 3.10+ kurulumunu kontrol et. `.bat` önce `py -3`,
  sonra `python` komutunu dener. Hata olursa konsol açık kalır.
- Pencereler açılmıyorsa konsoldaki tam hata mesajını paylaş.
- Alıcıda olay yoksa ikisinin de eşleştiğini, alıcı onayını ve gönderim
  durumunu kontrol et. Testte tuşları yalnız yeşil alan odaktayken dene.
- Gerçek girdide karakter tepki vermiyorsa önce hedef pencere başlığını
  kontrol et. Testte başarı, oyunun girdiyi kabul ettiğini kanıtlamaz.
